var xmlHttp;
var merchantIdArray = new Array();
var nameArray = new Array();
var currArray =new Array();
var firstLoad = '0';
$(document).ready(function(){
$('#ajaxLoadingIcon').hide();
var mername = $('#name');
mername.focus(function() {
	if(firstLoad=='0') {
	firstLoad='1';
	 $.ajax({
	type: "get",
	url: "/b2c2/ajaxmerinfoservice",
	beforeSend: function(XMLHttpRequest){
	 $('#ajaxLoadingIcon').show();
	},
	success: function(xml){
	 var index=0;
	  $(xml).find("merchant").each(function(){
			  var id_value=$(this).children("merchantid").text(); 
			  var name_value=$(this).children("name").text(); 
			  var curr_Value=$(this).children("currency").text(); 
			  merchantIdArray[index]= id_value;
			  nameArray[index]= name_value;
			  currArray[index]=curr_Value;
			  index++;
		});
	},
	complete: function(XMLHttpRequest, textStatus){
	 $('#ajaxLoadingIcon').hide();
	},
	error: function(){
	 alert('error');
	}
	});
	}
});

});

var a1,a2;

function initPage(inputName1,inputName2)
{
	input1='#'+inputName1;
	input2='#'+inputName2;
	a1 = $(input2).autocomplete( {
		lookup : nameArray,
		width : 500,
		delimiter : /(,|;)\s*/,
		onSelect : function(value) {
			var index = 0;
			for ( var i = 0; i < nameArray.length; i++) {
				if (value == nameArray[i]) {
					index = i;
					break;
				}
			}
			var temp=value.split(",");
			$(input1).val(jQuery.trim(temp[0]));
			$(input2).val(jQuery.trim(temp[2]));
		}
	});
	
}


