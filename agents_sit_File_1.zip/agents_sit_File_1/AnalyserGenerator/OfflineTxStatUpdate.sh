#!/bin/bash
AppPath=/opt/REDHAT/jws-5.5_SIT/tomcat/agents/sit/AnalyserGenerator
ClassPath=$AppPath/:$AppPath/lib/*:$AppPath/lib/ojdbc14.jar
JAVA_PATH=/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.302.b08-0.el8_4.x86_64/jre/bin/java

AppRun=AnalyserUpdate >> /data/TOMCAT_LOGS/Apache_SIT/Agent/AnalyserGenerator/AnalyserUpdate.log

cd $AppPath
$JAVA_PATH -cp $ClassPath $AppRun